from flask import Blueprint, send_file, request, jsonify
import pandas as pd
from io import BytesIO
import os
import mysql.connector
from werkzeug.utils import secure_filename
import traceback 

# Initialize DB connection (assuming 'HNU-exams' and credentials are correct)
db = mysql.connector.connect(
    host="localhost",
    user="root",        # Default for XAMPP
    password="",        # Leave empty unless you have one
    database="HNU-exams"  # Your DB name
)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

api_routes = Blueprint("api_routes", __name__)

@api_routes.route("/api/hello")
def hello():
    return jsonify({"message": "Hello from Flask backend!"})

# ======================================================================
# DOCTORS ROUTES
# ======================================================================

@api_routes.route("/api/v1/doctors/upload", methods=["GET"])
def download_doctor_template():
    # Create a simple Excel template in memory
    columns = [ "doctor_name", "email", "phone"]
    df = pd.DataFrame(columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="DoctorsTemplate")
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="doctor_template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@api_routes.route("/api/v1/doctors/upload", methods=["POST"])
def upload_doctor_file():
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    
    cursor = None
    
    try:
        file.save(filepath)
        df = pd.read_excel(filepath)
        
        required_columns = { "doctor_name", "email", "phone"}
        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            return jsonify({"error": f"Invalid Excel format. Missing columns: {', '.join(missing)}"}), 400

        cursor = db.cursor()
        records_to_insert = []
        
        for _, row in df.iterrows():
            name = str(row.get("doctor_name", "")).strip()
            email = str(row.get("email", "")).strip()
            phone = str(row.get("phone", "")).strip()
            
            if not name or not email:
                print(f"Skipping doctor row due to missing required data: {row.to_dict()}")
                continue
                
            records_to_insert.append((name, email, phone))

        sql = "INSERT INTO doctors (doctor_name, email, phone) VALUES (%s, %s, %s)"
        
        if records_to_insert:
            cursor.executemany(sql, records_to_insert)
            db.commit()
            count = len(records_to_insert)
            
            return jsonify({"message": f"Successfully uploaded {count} doctor(s)!"}), 201
        else:
            return jsonify({"message": "No valid doctor records found to upload."}), 200

    except Exception as e:
        if db.is_connected() and cursor:
            db.rollback()
        
        traceback.print_exc() 
        print("❌ Doctor Upload Error:", e)
        
        return jsonify({"error": f"An error occurred during doctor processing: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
        
        if os.path.exists(filepath):
            os.remove(filepath)
            
# ======================================================================
# ROOMS ROUTES
# ======================================================================

@api_routes.route("/api/v1/rooms/upload", methods=["GET"])
def download_room_template():
    """Provides an Excel template for room data upload."""
    # Define the columns for the Room template
    columns = [ "room_name", "capacity", "floor"]
    df = pd.DataFrame(columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="RoomsTemplate")
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="room_template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@api_routes.route("/api/v1/rooms/upload", methods=["POST"])
def upload_room_file():
    """Handles the upload and database insertion of room data from an Excel file."""
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    
    cursor = None
    
    try:
        file.save(filepath)
        df = pd.read_excel(filepath)
        
        # Validation: Check for required columns
        required_columns = { "room_name", "capacity", "floor"}
        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            return jsonify({"error": f"Invalid Excel format. Missing columns: {', '.join(missing)}"}), 400

        cursor = db.cursor()
        records_to_insert = []
        
        for _, row in df.iterrows():
            # Data extraction and cleaning/type casting
            room_name = str(row.get("room_name", "")).strip()
            floor = str(row.get("floor", "")).strip()

            
            # Convert capacity and floor to integer, handling potential NaN or missing values
            try:
                capacity = int(row.get("capacity", 0))
            except (ValueError, TypeError):
                print(f"Skipping room row due to invalid numeric data: {row.to_dict()}")
                continue
            
            if not room_name or capacity <= 0:
                print(f"Skipping room row due to missing required data: {row.to_dict()}")
                continue
                
            records_to_insert.append((room_name, capacity, floor))

        sql = "INSERT INTO rooms (room_name, capacity, floor) VALUES (%s, %s, %s)"
        
        if records_to_insert:
            cursor.executemany(sql, records_to_insert)
            db.commit()
            count = len(records_to_insert)
            
            return jsonify({"message": f"Successfully uploaded {count} room(s)!"}), 201
        else:
            return jsonify({"message": "No valid room records found to upload."}), 200

    except Exception as e:
        if db.is_connected() and cursor:
            db.rollback()
        
        traceback.print_exc() 
        print("❌ Room Upload Error:", e)
        
        return jsonify({"error": f"An error occurred during room processing: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
        
        if os.path.exists(filepath):
            os.remove(filepath)

# ======================================================================
# COURSES ROUTES
# ======================================================================

@api_routes.route("/api/v1/courses/upload", methods=["GET"])
def download_course_template():
    """Provides an Excel template for course data upload."""
    # Columns requested by the user
    columns = ["Course_code", "course_name", "course_arab_name", "credit_hrs", "prerequisite", "type", "lab"]
    df = pd.DataFrame(columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="CoursesTemplate")
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="course_template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@api_routes.route("/api/v1/courses/upload", methods=["POST"])
def upload_course_file():
    """Handles the upload and database insertion of course data from an Excel file."""
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    
    cursor = None
    
    try:
        file.save(filepath)
        df = pd.read_excel(filepath)
        
        # Validation: Check for required columns
        required_columns = {"Course_code", "course_name", "course_arab_name", "credit_hrs", "type"}
        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            return jsonify({"error": f"Invalid Excel format. Missing required columns: {', '.join(missing)}"}), 400

        cursor = db.cursor()
        records_to_insert = []
        
        for _, row in df.iterrows():
            course_code = str(row.get("Course_code", "")).strip()
            course_name = str(row.get("course_name", "")).strip()
            course_arab_name = str(row.get("course_arab_name", "")).strip()
            prerequisite = str(row.get("prerequisite", "")).strip()
            course_type = str(row.get("type", "")).strip()
            lab = str(row.get("lab", "")).strip()
            
            # Type Casting and Validation for credit_hrs
            try:
                # Convert to integer, defaulting to 0 if missing or invalid
                credit_hrs = int(row.get("credit_hrs", 0))
            except (ValueError, TypeError):
                print(f"Skipping course row due to invalid credit_hrs: {row.to_dict()}")
                continue
            
            # Simple check for required data
            if not course_code or not course_name or credit_hrs <= 0 or not course_type:
                print(f"Skipping course row due to missing required data: {row.to_dict()}")
                continue
                
            records_to_insert.append((
                course_code, 
                course_name, 
                course_arab_name, 
                credit_hrs, 
                prerequisite, 
                course_type, 
                lab
            ))

        sql = """
        INSERT INTO courses (
            Course_code, course_name, course_arab_name, credit_hrs, 
            prerequisite, type, lab
        ) 
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        
        if records_to_insert:
            cursor.executemany(sql, records_to_insert)
            db.commit()
            count = len(records_to_insert)
            
            return jsonify({"message": f"Successfully uploaded {count} course(s)!"}), 201
        else:
            return jsonify({"message": "No valid course records found to upload."}), 200

    except Exception as e:
        if db.is_connected() and cursor:
            db.rollback()
        
        traceback.print_exc() 
        print("❌ Course Upload Error:", e)
        
        return jsonify({"error": f"An error occurred during course processing: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
        
        if os.path.exists(filepath):
            os.remove(filepath)

# ======================================================================
# STUDENTS ROUTES
# ======================================================================

@api_routes.route("/api/v1/students/upload", methods=["GET"])
def download_student_template():
    """Provides an Excel template for student data upload."""
    columns = [
        "student_ID", "NID", "Arab_name", "Eng_name", "HNU_email", 
        "phone_number", "parent_number", "address", "medical_status"
    ]
    df = pd.DataFrame(columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="StudentsTemplate")
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="student_template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@api_routes.route("/api/v1/students/upload", methods=["POST"])
def upload_student_file():
    """Handles the upload and database insertion of student data from an Excel file."""
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    
    cursor = None
    
    try:
        file.save(filepath)
        df = pd.read_excel(filepath)
        
        # Validation: Check for required columns
        required_columns = {"student_ID", "NID", "Arab_name", "Eng_name", "HNU_email"}
        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            return jsonify({"error": f"Invalid Excel format. Missing required columns: {', '.join(missing)}"}), 400

        cursor = db.cursor()
        records_to_insert = []
        
        for _, row in df.iterrows():
            # Data extraction and cleaning (all cast to string for simplicity)
            student_id = str(row.get("student_ID", "")).strip()
            nid = str(row.get("NID", "")).strip()
            arab_name = str(row.get("Arab_name", "")).strip()
            eng_name = str(row.get("Eng_name", "")).strip()
            hnu_email = str(row.get("HNU_email", "")).strip()
            phone_number = str(row.get("phone_number", "")).strip()
            parent_number = str(row.get("parent_number", "")).strip()
            address = str(row.get("address", "")).strip()
            medical_status = str(row.get("medical_status", "")).strip()
            
            # Simple check for required data (IDs and names/email)
            if not student_id or not nid or not arab_name or not eng_name or not hnu_email:
                print(f"Skipping student row due to missing required data: {row.to_dict()}")
                continue
                
            records_to_insert.append((
                student_id, nid, arab_name, eng_name, hnu_email, 
                phone_number, parent_number, address, medical_status
            ))

        sql = """
        INSERT INTO students (
            student_ID, NID, Arab_name, Eng_name, HNU_email, 
            phone_number, parent_number, address, medical_status
        ) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        if records_to_insert:
            cursor.executemany(sql, records_to_insert)
            db.commit()
            count = len(records_to_insert)
            
            return jsonify({"message": f"Successfully uploaded {count} student(s)!"}), 201
        else:
            return jsonify({"message": "No valid student records found to upload."}), 200

    except Exception as e:
        if db.is_connected() and cursor:
            db.rollback()
        
        traceback.print_exc() 
        print("❌ Student Upload Error:", e)
        
        return jsonify({"error": f"An error occurred during student processing: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
        
        if os.path.exists(filepath):
            os.remove(filepath)



# ======================================================================
# REGISTRATION ROUTES (UPDATED)
# ======================================================================
@api_routes.route("/api/v1/Student-registration", methods=["GET"])
def get_all_registrations():
    """Fetch all registration records."""
    try:
        cursor = db.cursor(dictionary=True)
        cursor.execute("""
            SELECT 
                NID, level, student_ID, course, 
                student_group, student_name, payment, notes 
            FROM registration
        """)
        rows = cursor.fetchall()
        return jsonify(rows), 200
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()


@api_routes.route("/api/v1/Student-registration", methods=["POST"])
def add_registration():
    """Add a single student registration record."""
    try:
        data = request.get_json()

        required_fields = ["NID", "level", "student_ID", "course", "student_name"]
        missing = [f for f in required_fields if f not in data or not data[f]]

        if missing:
            return jsonify({"error": f"Missing required fields: {', '.join(missing)}"}), 400

        sql = """
        INSERT INTO registration (
            NID, level, student_ID, course, student_group, student_name, payment, notes
        ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """
        values = (
            data.get("NID"),
            data.get("level"),
            data.get("student_ID"),
            data.get("course"),
            data.get("student_group"),
            data.get("student_name"),
            data.get("payment"),
            data.get("notes")
        )

        cursor = db.cursor()
        cursor.execute(sql, values)
        db.commit()

        return jsonify({"message": "✅ Registration record added successfully!"}), 201
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()


@api_routes.route("/api/v1/Student-registration/<student_ID>", methods=["PUT"])
def update_registration(student_ID):
    """Update a registration record by student_ID."""
    try:
        data = request.get_json()

        fields = ["NID", "level", "course", "student_group", "student_name", "payment", "notes"]
        updates = []
        values = []

        for field in fields:
            if field in data:
                updates.append(f"{field} = %s")
                values.append(data[field])

        if not updates:
            return jsonify({"error": "No fields provided for update."}), 400

        sql = f"UPDATE registration SET {', '.join(updates)} WHERE student_ID = %s"
        values.append(student_ID)

        cursor = db.cursor()
        cursor.execute(sql, values)
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No registration found with that student_ID."}), 404

        return jsonify({"message": "✅ Registration updated successfully!"}), 200
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()


@api_routes.route("/api/v1/Student-registration/<student_ID>", methods=["DELETE"])
def delete_registration(student_ID):
    """Delete a registration record by student_ID."""
    try:
        cursor = db.cursor()
        cursor.execute("DELETE FROM registration WHERE student_ID = %s", (student_ID,))
        db.commit()

        if cursor.rowcount == 0:
            return jsonify({"message": "No registration found with that student_ID."}), 404

        return jsonify({"message": "🗑️ Registration record deleted successfully!"}), 200
    except Exception as e:
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500
    finally:
        cursor.close()


@api_routes.route("/api/v1/Student-registration/upload", methods=["GET"])
def download_registration_template():
    """Provides an Excel template for student registration data upload."""
    columns = [
        "NID", 
        "level", 
        "student_ID", 
        "course", 
        "student_group", 
        "student_name", 
        "payment", 
        "notes"
    ]
    df = pd.DataFrame(columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="RegistrationTemplate")
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="registration_template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


@api_routes.route("/api/v1/Student-registration/upload", methods=["POST"])
def upload_registration_file():
    """Handles the upload and database insertion of updated student registration data."""
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)

    cursor = None

    try:
        file.save(filepath)
        df = pd.read_excel(filepath)

        # Validate required columns
        required_columns = {"NID", "level", "student_ID", "course", "student_name"}
        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            return jsonify({
                "error": f"Invalid Excel format. Missing required columns: {', '.join(missing)}"
            }), 400

        cursor = db.cursor()
        records_to_insert = []

        for _, row in df.iterrows():
            # Extract and clean each value
            NID = str(row.get("NID", "")).strip()
            level = str(row.get("level", "")).strip()
            student_ID = str(row.get("student_ID", "")).strip()
            course = str(row.get("course", "")).strip()
            student_group = str(row.get("student_group", "")).strip()
            student_name = str(row.get("student_name", "")).strip()
            payment = str(row.get("payment", "")).strip()
            notes = str(row.get("notes", "")).strip()

            # Skip invalid rows
            if not NID or not level or not student_ID or not course or not student_name:
                print(f"Skipping registration row due to missing data: {row.to_dict()}")
                continue

            records_to_insert.append((
                NID, level, student_ID, course, student_group, student_name, payment, notes
            ))

        # Insert SQL — make sure your DB table has these columns
        sql = """
        INSERT INTO registration (
            NID, level, student_ID, course, student_group, student_name, payment, notes
        ) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
        """

        if records_to_insert:
            cursor.executemany(sql, records_to_insert)
            db.commit()
            count = len(records_to_insert)
            return jsonify({"message": f"✅ Successfully uploaded {count} registration record(s)!"}), 201
        else:
            return jsonify({"message": "No valid registration records found to upload."}), 200

    except Exception as e:
        if db.is_connected() and cursor:
            db.rollback()

        traceback.print_exc()
        print("❌ Registration Upload Error:", e)
        return jsonify({"error": f"An error occurred during registration processing: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
        if os.path.exists(filepath):
            os.remove(filepath)

# ======================================================================
# NEW EXAMS ROUTES
# ======================================================================

@api_routes.route("/api/v1/exams/upload", methods=["GET"])
def download_exam_template():
    """Provides an Excel template for exam data upload (includes 'level')."""
    columns = [
        "Exam_id", "year", "semester", "type", "period_id", "date", 
        "program_code", "course_code", "day", "level"
    ]
    df = pd.DataFrame(columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="ExamsTemplate")
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="exam_template.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


@api_routes.route("/api/v1/exams/upload", methods=["POST"])
def upload_exam_file():
    """Handles the upload and database insertion of exam data from an Excel file (with 'level')."""
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    
    cursor = None
    
    try:
        file.save(filepath)
        df = pd.read_excel(filepath)
        
        # Validation: Check for required columns
        required_columns = {"Exam_id", "year", "semester", "course_code", "date", "level"}
        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            return jsonify({"error": f"Invalid Excel format. Missing required columns: {', '.join(missing)}"}), 400

        cursor = db.cursor()
        records_to_insert = []
        
        for _, row in df.iterrows():
            exam_id = str(row.get("Exam_id", "")).strip()
            year = str(row.get("year", "")).strip()
            semester = str(row.get("semester", "")).strip()
            exam_type = str(row.get("type", "")).strip()
            period_id = str(row.get("period_id", "")).strip()
            exam_date = str(row.get("date", "")).strip()
            program_code = str(row.get("program_code", "")).strip()
            course_code = str(row.get("course_code", "")).strip()
            day = str(row.get("day", "")).strip()
            level = str(row.get("level", "")).strip()
            
            # Validate year
          
            
            # Skip incomplete rows
            if not exam_id or not semester or not course_code or not exam_date or len(year) <= 0:
                print(f"Skipping exam row due to missing required data: {row.to_dict()}")
                continue
                
            records_to_insert.append((
                exam_id, year, semester, exam_type, period_id, 
                exam_date, program_code, course_code, day, level
            ))

        sql = """
        INSERT INTO exam (
            Exam_id, year, semester, type, period_id, date, 
            program, code_course, day, level
        ) 
        VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """
        
        if records_to_insert:
            cursor.executemany(sql, records_to_insert)
            db.commit()
            count = len(records_to_insert)
            
            return jsonify({"message": f"✅ Successfully uploaded {count} exam record(s)!"}), 201
        else:
            return jsonify({"message": "⚠️ No valid exam records found to upload."}), 200

    except Exception as e:
        if db.is_connected() and cursor:
            db.rollback()
        
        traceback.print_exc() 
        print("❌ Exam Upload Error:", e)
        
        return jsonify({"error": f"An error occurred during exam processing: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
        
        if os.path.exists(filepath):
            os.remove(filepath)


# ----------------------------------------------------------------------
# LEGAN ROUTES (Corrected)
# ----------------------------------------------------------------------
@api_routes.route("/api/v1/legans/upload", methods=["GET"])
def download_legan_template(): # <-- Renamed function
    """Provides an Excel template for Legan (Exam Committee/Control) data upload."""
    columns = [
        "Legan_id", "legan_name", "room_id", "level", "capacity", "full_capacity", 
        "program"
    ]
    df = pd.DataFrame(columns=columns)

    output = BytesIO()
    with pd.ExcelWriter(output, engine='openpyxl') as writer:
        df.to_excel(writer, index=False, sheet_name="LegansTemplate") # <-- Renamed sheet
    output.seek(0)

    return send_file(
        output,
        as_attachment=True,
        download_name="legan_template.xlsx", # <-- Renamed file
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@api_routes.route("/api/v1/legans/upload", methods=["POST"])
def upload_legan_file(): # <-- Renamed function
    """Handles the upload and database insertion of Legan data from an Excel file."""
    if "file" not in request.files:
        return jsonify({"error": "No file part"}), 400

    file = request.files["file"]
    if file.filename == "":
        return jsonify({"error": "No file selected"}), 400

    filename = secure_filename(file.filename)
    filepath = os.path.join(UPLOAD_FOLDER, filename)
    
    cursor = None
    
    try:
        file.save(filepath)
        df = pd.read_excel(filepath)
        
        # Validation: Check for required columns
        required_columns = {"Legan_id", "legan_name", "room_id", "level", "capacity", "full_capacity", "program"}
        if not required_columns.issubset(df.columns):
            missing = required_columns - set(df.columns)
            return jsonify({"error": f"Invalid Excel format. Missing required columns: {', '.join(missing)}"}), 400

        cursor = db.cursor()
        records_to_insert = []
        
        for _, row in df.iterrows():
            # Data extraction and cleaning
            Legan_id = str(row.get("Legan_id", "")).strip()
            legan_name = str(row.get("legan_name", "")).strip()
            room_id_str = str(row.get("room_id", "")).strip()
            level_str = str(row.get("level", "")).strip()
            capacity_str = str(row.get("capacity", "")).strip()
            full_capacity_str = str(row.get("full_capacity", "")).strip()
            program = str(row.get("program", "")).strip()
       
            # Type Casting and Validation for numeric fields
            try:
                # Assuming these should be integers
                room_id = int(float(room_id_str)) if room_id_str else 0
                level = (level_str) if level_str else 'level 1'
                capacity = int(float(capacity_str)) if capacity_str else 0
                full_capacity = int(float(full_capacity_str)) if full_capacity_str else 0
            except (ValueError, TypeError):
                print(f"Skipping legan row due to invalid numeric data: {row.to_dict()}")
                continue
            
            # Simple check for required data (Legan_id, name, program, and at least one capacity field > 0)
            if not Legan_id or not legan_name or not program or (capacity <= 0 and full_capacity <= 0):
                print(f"Skipping legan row due to missing required data: {row.to_dict()}")
                continue
                
            records_to_insert.append((
                Legan_id, legan_name, room_id, level, capacity, 
                full_capacity, program
            ))

        # *** CRITICAL FIX: Corrected table name from 'exam' to 'legans' 
        # (Assuming the table is named 'legans' and columns match the provided list)
        sql = """
        INSERT INTO legan (
            Legan_id, legan_name, room_id, level, capacity, 
            full_capacity, program
        ) 
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        """
        
        if records_to_insert:
            cursor.executemany(sql, records_to_insert)
            db.commit()
            count = len(records_to_insert)
            
            return jsonify({"message": f"Successfully uploaded {count} legan record(s)!"}), 201
        else:
            return jsonify({"message": "No valid legan records found to upload."}), 200

    except Exception as e:
        if db.is_connected() and cursor:
            db.rollback()
        
        traceback.print_exc() 
        print("❌ Legan Upload Error:", e)
        
        return jsonify({"error": f"An error occurred during legan processing: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
        
        if os.path.exists(filepath):
            os.remove(filepath)



@api_routes.route("/api/v1/exams", methods=["GET"])
def get_all_exams():
    """Fetch all exam records from the database."""
    cursor = None
    try:
        cursor = db.cursor(dictionary=True)  # Return rows as dicts (column:value)
        sql = """
        SELECT 
            Exam_id, 
            year, 
            semester, 
            type, 
            period_id, 
            date, 
            program AS program, 
            code_course AS course_code, 
            day,
            level
        FROM exam
        ORDER BY year DESC, semester ASC, date ASC
        """
        cursor.execute(sql)
        exams = cursor.fetchall()

        # If no records found
        if not exams:
            return jsonify({"message": "No exams found", "data": []}), 200

        return jsonify({
            "message": f"Fetched {len(exams)} exam record(s) successfully",
            "data": exams
        }), 200

    except Exception as e:
        traceback.print_exc()
        print("❌ Exam Fetch Error:", e)
        return jsonify({"error": f"Failed to fetch exams: {str(e)}"}), 500

    finally:
        if cursor:
            cursor.close()
